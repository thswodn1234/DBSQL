package pnusw02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Pnusw02 {
	static int choice;
	static String table;
	Connection con;

	public Pnusw02() {
		String Driver = "com.mysql.cj.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/pnusw02";
		String userid = "root";
		String pwd = "tiger";

		try { /* 드라이버를 찾는 과정 */
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("드라이버 로드 성공");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		try { /* 데이터베이스를 연결하는 과정 */
			System.out.println("데이터베이스 연결 준비...");
			con = DriverManager.getConnection(url, userid, pwd);
			System.out.println("데이터베이스 연결 성공");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void insertQuery() {
		String query = "insert into member  (id, pass, name)" + "values (?,?,?)";
		try {
			PreparedStatement preparedStmt = con.prepareStatement(query);
			Scanner sc = new Scanner(System.in);
			System.out.println("학과번호 :");
			String s1 = sc.nextLine();
			System.out.println("학과명 :");
			String s2 = sc.nextLine();
			System.out.println("전화번호:");
			String s3 = sc.nextLine();
			preparedStmt.setString(1, s1);
			preparedStmt.setString(2, s2);
			preparedStmt.setString(3, s3);
			preparedStmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}// 입력 메소드

	public void deleteQuery() {
		Scanner sc = new Scanner(System.in);
		System.out.println("삭제할 학과번호를 입력하세요:");
		String s1 = sc.nextLine();
		String query = "DELETE FROM 학과 WHERE 학과번호 = " + s1;
		try {
			PreparedStatement preparedStmt = con.prepareStatement(query);
			preparedStmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}// 삭제 메소드

	public void updateQuery() {
		// 1122 업데이트 안됨
		Scanner sc = new Scanner(System.in);
		System.out.println("변경할 학과번호를 입력하세요:");
		String s1 = sc.nextLine();
		System.out.println("변경된 학과명를 입력하세요:");
		String s2 = sc.nextLine();
		System.out.println(s2);
		String query = "UPDATE 학과 SET 학과명 = " + s2 + " WHERE 학과번호=" + s1;
		try {
			PreparedStatement preparedStmt = con.prepareStatement(query);
			preparedStmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}// 갱신 메소드

	public void selectQuery() {

		try { /* 데이터베이스에 질의 결과를 가져오는 과정 */
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(String.format("select * from %s", table));

			ResultSetMetaData rsmd = rs.getMetaData();
			int colCnt = rsmd.getColumnCount(); // 컬럼 갯수 얻어오기

			System.out.println(" 제목줄 ");
			for (int i = 1; i <= colCnt; i++) {
				System.out.printf("\t");
				 System.out.printf("%-12s",rsmd.getColumnName(i).trim());
				 System.out.printf("\t");
				 }
			System.out.println(); 
			
			 
			while (rs.next()) {
				
				for (int i = 1; i <= colCnt; i++) {
					System.out.printf("\t"+"%-14s",rs.getString(rsmd.getColumnName(i)).trim() );
					System.out.printf("\t");


				}
				System.out.println();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	} // 검색 메소드

	public static void main(String[] args) {
//		테이블을 생성하고, Insert, Select, Update, Delete가 가능하도록 프로그래밍 하세요
//		▪ DB는 sql파일로 백업 받아서 제출(DB명은 pnuswOO으로 할것)
//		▪ Java는 소스코드 파일로 제출
		// HOW?
		// 테이블을 고른다
		// 메서드를 고른다.

		Scanner in = new Scanner(System.in);
		while (true) {
			Pnusw02 scon = new Pnusw02();
			System.out.println("Enter a choice:");
			System.out.println("1. 강의");
			System.out.println("2. 학과");
			System.out.println("3. 학생");
			System.out.println("4. 학점");
			System.out.println("5. 학생수강성적");
			System.out.println("6. Exit");

			choice = in.nextInt();
			System.out.println("--------------------------------------");
			switch (choice) {
			case 1:
				table = "강의";
				break;
			case 2:
				table = "학과";
				break;
			case 3:
				table = "학생";
				break;
			case 4:
				table = "학점";
				break;
			case 5:
				table = "학생수강성적";
				break;

			case 6:
				System.out.println("프로그램을 종료합니다.");
				System.exit(0);
				break;
			default:
				System.out.println("잘못된 선택입니다.");
				break;
			}

			System.out.println("Enter a Method: ");
			System.out.println("1. insert");
			System.out.println("2. update");
			System.out.println("3. delete");
			System.out.println("4. select");
			System.out.println("5. Exit");

			choice = in.nextInt();
			System.out.println("--------------------------------------");
			switch (choice) {
			case 1:
				scon.insertQuery();
				break;
			case 2:
				scon.updateQuery();
				break;
			case 3:
				scon.deleteQuery();
				break;
			case 4:
				scon.selectQuery();
				break;
			case 5:
				System.out.println("프로그램을 종료합니다.");
				System.exit(0);
				break;
			default:
				System.out.println("잘못된 선택입니다.");
				break;
			}
			System.out.println("-----------------------------------");

		}
	}

}
